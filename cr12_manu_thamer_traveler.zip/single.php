<?php get_header(); ?>

<div class="container text-center">
    <div class="content">

        <?php if (have_posts()) : ?>
            <!--  If there are posts available  -->

            <?php while (have_posts()) : the_post(); ?>
                <!-- if there are posts, iterate the posts in the loop-->



                <h3 class="card-text"><?php the_title(); ?></h3>
                <!--retrieves blog title-->

                <?php if (has_post_thumbnail()) : ?>
                    <?php the_post_thumbnail('medium_large'); ?>
                <?php endif; ?>

                <hr>



                <p class="card-text"><?php the_time('F j, Y g:i a'); ?></p>
                <!--retrieves date blog entry was created-->



                <p class="card-text">Author: <?php the_author(); ?></p>
                <!--retrieves author of blog entry-->

                <hr>

                <p class="card-text"><?php the_content(); ?></p>
                <!--retrieves content-->

                <!-- enable comments -->
                <div><?php comments_template(); ?></div>

                <div class="d-flex justify-content-center">
                    <?php
                    if (is_active_sidebar('sidebar')) :
                        dynamic_sidebar('Sidebar');
                    endif;
                    ?>
                </div>
    </div>

<?php endwhile; ?>
<!--end the while loop-->

<?php else : ?>
    <!-- if no posts are found then: -->

    <p>No posts found</p>
<?php endif; ?>
</div>
<div class="d-flex justify-content-center">
    <?php get_footer(); ?>
</div>
</div>