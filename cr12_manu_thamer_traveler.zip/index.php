<?php get_header(); ?>


<div class="container text-center">

   <h2 class="text-center"><?php bloginfo('name'); ?></h2>
   <h5 class="text-center"><?php bloginfo('description'); ?></h5>

   <div class="row row-cols-3 my-5 mx-2 justify-content-around ">

      <?php if (have_posts()) : ?>
         <!--  If there are posts available  -->

         <?php while (have_posts()) : the_post(); ?>
            <!-- if there are posts, iterate the posts in the loop-->

            <div class="card border-dark mx-1 mb-4">
               <div class="card h-100 ">
                  <div class="card-header bg-light text-center">
                     <a href="<?php the_permalink(); ?>">
                        <h3><?php the_title(); ?></h3>
                  </div>

                  <?php if (has_post_thumbnail()) : ?>

                     <img class="card-img-top" src="<?php the_post_thumbnail(array(400, 250)); ?> <?php endif; ?> <a href="<?php the_permalink(); ?>">
                     </a>


                     <div class="card-body">
                        <h6 class="card-text d-flex justify-content-between">
                           <div>
                              <p><?php the_time('F j, Y g:i a'); ?></p>
                           </div>
                           <div>
                              <p><?php the_author(); ?></p>
                           </div>
                        </h6>

                        <p><?php the_excerpt(); ?></p>

                     </div>
               </div>
            </div>

         <?php endwhile; ?>


      <?php else : ?>


         <p>No posts found</p> 
      <?php endif; ?>
   
   </div>
   <div class= "d-flex justify-content-center">
<?php get_footer(); ?>
</div>

</div>



