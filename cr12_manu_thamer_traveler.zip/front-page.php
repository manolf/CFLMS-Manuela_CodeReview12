<?php get_header(); ?>

<div class="container">

    <!-- <div class="image"><img src="./wordpress/wp-content/uploads/2020\07/rotti-300x200.jpg" alt="man with rottweiler">
    </div> -->
    <div class="image"><img src="https://cdn.pixabay.com/photo/2018/05/17/16/03/compass-3408928_1280.jpg" alt="map">
    </div>

    


    <div class="d-flex justify-content-center">
        <?php get_footer(); ?>
    </div>

</div>

</div>