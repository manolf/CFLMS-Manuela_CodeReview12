<?php
if(is_active_sidebar('sidebar')):
    dynamic_sidebar('footer_widget');
endif;
?>


<?php get_footer(); ?>

</body>

</html>