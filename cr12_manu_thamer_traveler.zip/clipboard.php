<img><?php if(has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail(array(300,300)); ?> <!--Größe des thumbnails-->
                                    <?php endif; ?></img>